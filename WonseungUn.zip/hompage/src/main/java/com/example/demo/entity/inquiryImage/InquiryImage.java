package com.example.demo.entity.inquiryImage;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InquiryImage {
	private Long iino;
	private String iiName;
	private Long inno;
	
}
