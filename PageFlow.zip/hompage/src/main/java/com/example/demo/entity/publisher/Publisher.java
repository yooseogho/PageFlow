package com.example.demo.entity.publisher;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Publisher {
	private Long publisherCode;
	private String publisherName;
}
