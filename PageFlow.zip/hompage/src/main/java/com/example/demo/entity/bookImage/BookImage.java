package com.example.demo.entity.bookImage;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookImage {
	private Long bino;
	private String imageName;
	private Long bno;
}
